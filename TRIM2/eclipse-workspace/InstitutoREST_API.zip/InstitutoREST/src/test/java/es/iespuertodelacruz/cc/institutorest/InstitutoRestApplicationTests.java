package es.iespuertodelacruz.cc.institutorest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstitutoRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
