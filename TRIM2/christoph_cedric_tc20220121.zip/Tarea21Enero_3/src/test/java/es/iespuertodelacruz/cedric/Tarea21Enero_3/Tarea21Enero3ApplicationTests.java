package es.iespuertodelacruz.cedric.Tarea21Enero_3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tarea21Enero3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
