package es.iespuertodelacruz.cedric.Tarea21Enero_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tarea21Enero3Application {

	public static void main(String[] args) {
		SpringApplication.run(Tarea21Enero3Application.class, args);
	}

}
