#!/bin/bash

##################################
#
#   Arrancar La Api de Instituto
#   Autor: Cedric Christoph
#   Version 1.0
#
##################################

java -jar InstitutoREST.jar