package es.iespuertodelacruz.cedric.tarea21enero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tarea21EneroApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tarea21EneroApplication.class, args);
	}

}
