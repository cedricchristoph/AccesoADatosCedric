package es.iespuertodelacruz.cedric.tarea21enero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tarea21EneroApplicationTests {

	@Test
	void contextLoads() {
	}

}
