Web App Instituto – Cedric Christoph

Para poder utilizar el software junto a la BBDD correctamente se debe
introducir el usuario y contraseña con la que trabajará el software
internamente a es.iespuertodelacruz.cc.utils.Globals.java en las constantes
respectivas.

CONST_APP_USER: Usuario SQL
CONST_APP_PWD: Contraseña usuario SQL.

(Se recomienda establecer un usuario SQL especial con derechos únicamente para
gestionar la base de datos de 'instituto' con derechos de GRANT, SELECT, INSERT, DELETE, UPDATE)

Para montar la base de datos se deben ejecutar las sentencias proporcionadas
en el fichero instituto.sql.

Inicialmente se crea un único usuario Administrador con las siguientes credenciales:

    user: admin
    contraseña: 1234
    
(Se recomienda entrar a Mi Perfil (¡Hola admin!) y cambiar la contraseña).

