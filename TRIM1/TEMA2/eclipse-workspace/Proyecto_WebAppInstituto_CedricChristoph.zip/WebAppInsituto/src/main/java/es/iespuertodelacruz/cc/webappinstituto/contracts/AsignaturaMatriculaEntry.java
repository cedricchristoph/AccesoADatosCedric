package es.iespuertodelacruz.cc.webappinstituto.contracts;

public abstract class AsignaturaMatriculaEntry {

	public static final String TABLE_NAME = "asignatura_matricula";
	
	public static final String ID = "id";
	public static final String IDMATRICULA = "idmatricula";
	public static final String IDASIGNATURA = "idasignatura";
	
}
