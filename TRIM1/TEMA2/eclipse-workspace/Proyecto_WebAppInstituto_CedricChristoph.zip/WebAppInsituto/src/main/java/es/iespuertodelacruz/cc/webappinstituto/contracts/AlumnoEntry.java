package es.iespuertodelacruz.cc.webappinstituto.contracts;

public abstract class AlumnoEntry {

	public static final String TABLE_NAME = "alumnos";
	
	public static final String DNI = "dni";
	public static final String NOMBRE = "nombre";
	public static final String APELLIDOS = "apellidos";
	public static final String FECHANACIMIENTO = "fechanacimiento";
	
}
