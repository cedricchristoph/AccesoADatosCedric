package es.iespuertodelacruz.cc.webappinstituto.contracts;

public abstract class MatriculaEntry {

	public static final String TABLE_NAME = "matriculas";
	
	public static final String ID = "idmatricula";
	public static final String DNI = "dni";
	public static final String YEAR = "year";
	
}
