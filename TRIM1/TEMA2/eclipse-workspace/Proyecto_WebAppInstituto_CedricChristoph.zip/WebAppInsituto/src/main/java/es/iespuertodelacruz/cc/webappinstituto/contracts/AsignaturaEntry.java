package es.iespuertodelacruz.cc.webappinstituto.contracts;

public abstract class AsignaturaEntry {

	public static final String TABLE_NAME = "asignaturas";
	
	public static final String ID = "idasignatura";
	public static final String NOMBRE = "nombre";
	public static final String CURSO = "curso";
	
}
