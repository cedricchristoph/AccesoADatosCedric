package es.iespuertodelacruz.cc.webappinstituto.contracts;

public abstract class UserEntry {

	public static final String TABLE_NAME = "users";
	
	public static final String USER = "user";
	public static final String EMAIL = "email";
	public static final String HASH = "hash";
	public static final String ACTIVE = "active";
	public static final String TYPE = "type";
	
}
